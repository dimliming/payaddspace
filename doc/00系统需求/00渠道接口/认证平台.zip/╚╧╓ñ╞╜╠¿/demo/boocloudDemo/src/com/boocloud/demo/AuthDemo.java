package com.boocloud.demo;

import com.boocloud.demo.Md5Utils;
import com.google.common.base.Charsets;
import com.google.common.base.Strings;

import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * 带卡号四要素验证
 * Created by qjj on 15-11-24.
 */
public class AuthDemo {
    //每个商户分配md5盐值
    static String signKey="68f1ba2603894da1b946b2541947b78c";
    //分配商户号
    static String merid="310012171000001";

    static String pan="****************";
    static  String certifId="************";
    //static  String certifId="332522199602048234";
    static String username="曲***";
    static String phone ="18817****";

    public static void main(String[] args) throws Exception {
        Map<String, String> contentData = new TreeMap<String, String>();
        contentData.put("version", "5.0.0");
        contentData.put("encoding", "UTF-8");
        //00 认证
        contentData.put("txnType", "00");
        contentData.put("merId",merid);
        //defaultPayType 位图形式　第一位数字是1代表卡号，第二为数字1代表验证身份证，第三位为数字1代表验证姓名，第四位为数字１代表验证手机
        contentData.put("defaultPayType","1110");
        contentData.put("orderId", String.valueOf(System.currentTimeMillis()));
        contentData.put("txnTime", new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()));
        contentData.put("accNo", pan);
        //01 卡
        contentData.put("accType","01");
        //01身份证
        contentData.put("certifTp","01");
        contentData.put("certifId",certifId);
        contentData.put("customerNm",username);
       contentData.put("phoneNo",phone);
       String sign= signData(contentData);
        contentData.put("signature",sign);
      HttpClient client = new HttpClient("http://127.0.0.1:8080/auth.htm",6000,60000);
        client.send(contentData,"utf-8");
       String respons=    client.getResult();
        System.out.println(URLDecoder.decode(respons,"utf-8"));


    }

    public static String signData(Map<String, String> contentData) {
        Map.Entry<String, String> obj = null;
        Map<String, String> submitFromData = new TreeMap<String, String>();
        for (Iterator<?> it = contentData.entrySet().iterator(); it.hasNext();) {
            obj = (Map.Entry<String, String>) it.next();
            String value = obj.getValue();
            if (!Strings.isNullOrEmpty(value)) {
                // 对value值进行去除前后空处理
                submitFromData.put(obj.getKey(), value.trim());
            }
        }

      String signData = coverMap2String(submitFromData)+"&signkey="+signKey;
       String sign = Md5Utils.md5(signData.getBytes(Charsets.UTF_8));
        return sign;
    }
    public static String coverMap2String(Map<String, String> data) {
        TreeMap tree = new TreeMap();
        Iterator it = data.entrySet().iterator();

        StringBuffer sf1 = new StringBuffer();

        while(it.hasNext()) {
            Map.Entry en = (Map.Entry)it.next();
            sf1.append(en.getKey() + "=" + en.getValue() + "&");
        }

        return sf1.substring(0, sf1.length() - 1);
    }
}
